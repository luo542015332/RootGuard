// PandaSU Zygisk Module - 真正的 Root 隐藏实现
// 使用标准 Zygisk API 实现文件隐藏和属性伪装

#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <android/log.h>
#include <dlfcn.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <errno.h>
#include <dirent.h>

#include "zygisk.hpp"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "PandaSU-Zygisk", __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "PandaSU-Zygisk", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "PandaSU-Zygisk", __VA_ARGS__)

// 隐藏的文件路径关键词
static const char* HIDE_PATTERNS[] = {
    "/su/bin/su",
    "/su/su",
    "/sbin/su",
    "/system/bin/su",
    "/system/xbin/su",
    "/system/xbin/ksu",
    "/data/adb/su",
    "/data/adb/magisk",
    "/data/adb/ksu",
    "/data/adb/busybox",
    "/system/bin/busybox",
    "/system/xbin/busybox",
    "/data/adb/modules",
    "/data/adb/ksu_bind",
};

// 检查路径是否需要隐藏
static bool should_hide_path(const char* path) {
    if (path == nullptr) return false;

    for (size_t i = 0; i < sizeof(HIDE_PATTERNS) / sizeof(HIDE_PATTERNS[0]); i++) {
        if (strstr(path, HIDE_PATTERNS[i]) != nullptr) {
            LOGD("Hiding path: %s", path);
            return true;
        }
    }
    return false;
}

// ============ PLT Hook 实现 ============

// 原始函数指针
static int (*original_open)(const char*, int, ...) = nullptr;
static int (*original_stat)(const char*, struct stat*) = nullptr;
static int (*original_lstat)(const char*, struct stat*) = nullptr;
static int (*original_access)(const char*, int) = nullptr;
static int (*original_readlink)(const char*, char*, size_t) = nullptr;

// Hooked open
static int hooked_open(const char* path, int flags, ...) {
    if (should_hide_path(path)) {
        errno = ENOENT;
        return -1;
    }

    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
        return original_open(path, flags, mode);
    }

    return original_open(path, flags);
}

// Hooked stat
static int hooked_stat(const char* path, struct stat* buf) {
    if (should_hide_path(path)) {
        errno = ENOENT;
        return -1;
    }
    return original_stat(path, buf);
}

// Hooked lstat
static int hooked_lstat(const char* path, struct stat* buf) {
    if (should_hide_path(path)) {
        errno = ENOENT;
        return -1;
    }
    return original_lstat(path, buf);
}

// Hooked access
static int hooked_access(const char* path, int mode) {
    if (should_hide_path(path)) {
        return -1;
    }
    return original_access(path, mode);
}

// Hooked readlink
static int hooked_readlink(const char* path, char* buf, size_t bufsiz) {
    if (should_hide_path(path)) {
        errno = ENOENT;
        return -1;
    }
    return original_readlink(path, buf, bufsiz);
}

// ============ Zygisk 模块实现 ============

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

class PandaModule : public zygisk::ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api = api;
        this->env = env;
        LOGI("PandaSU Zygisk loaded");
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        // 获取进程名
        const char *process = env->GetStringUTFChars(args->nice_name, nullptr);
        LOGD("preAppSpecialize: %s", process);
        env->ReleaseStringUTFChars(args->nice_name, process);
    }

    void postAppSpecialize(const AppSpecializeArgs *args) override {
        // 应用进程专业化后执行 Hook
        LOGD("postAppSpecialize called");
        setup_hooks();
    }

    void preServerSpecialize(ServerSpecializeArgs *args) override {
        LOGD("preServerSpecialize called");
    }

    void postServerSpecialize(const ServerSpecializeArgs *args) override {
        // system_server 专业化后执行 Hook
        LOGD("postServerSpecialize called");
        setup_hooks();
    }

private:
    Api *api;
    JNIEnv *env;

    void setup_hooks() {
        // 获取系统库的 dev 和 inode
        // 然后注册 PLT Hook
        FILE *maps = fopen("/proc/self/maps", "r");
        if (maps == nullptr) {
            LOGE("Failed to open /proc/self/maps");
            return;
        }

        char line[512];
        while (fgets(line, sizeof(line), maps)) {
            // 查找 libc.so
            if (strstr(line, "libc.so") != nullptr) {
                char perms[8], dev[16], pathname[256];
                unsigned long start, end, inode;
                sscanf(line, "%lx-%lx %s %lx %s %lu %s",
                       &start, &end, perms, &inode, dev, &inode, pathname);

                if (inode > 0 && strlen(pathname) > 0) {
                    dev_t dev_id = 0;
                    sscanf(dev, "%llx", &dev_id);

                    LOGD("Found libc.so: dev=%ld, inode=%lu, path=%s",
                         (long)dev_id, inode, pathname);

                    // 注册 PLT Hook
                    api->pltHookRegister(dev_id, inode, "open", (void*)hooked_open, (void**)&original_open);
                    api->pltHookRegister(dev_id, inode, "stat", (void*)hooked_stat, (void**)&original_stat);
                    api->pltHookRegister(dev_id, inode, "lstat", (void*)hooked_lstat, (void**)&original_lstat);
                    api->pltHookRegister(dev_id, inode, "access", (void*)hooked_access, (void**)&original_access);
                    api->pltHookRegister(dev_id, inode, "readlink", (void*)hooked_readlink, (void**)&original_readlink);

                    break;
                }
            }
        }
        fclose(maps);

        // 提交 Hook
        if (api->pltHookCommit()) {
            LOGI("PLT Hook committed successfully");
        } else {
            LOGE("PLT Hook commit failed");
        }
    }
};

// 注册模块
REGISTER_ZYGISK_MODULE(PandaModule)