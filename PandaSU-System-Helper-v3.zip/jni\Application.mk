# Application.mk for PandaSU Zygisk Module
APP_ABI      := arm64-v8a
APP_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti -fvisibility=hidden -fvisibility-inlines-hidden
APP_STL      := c++_static
APP_PLATFORM := android-21
