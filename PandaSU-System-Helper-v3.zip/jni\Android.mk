# PandaSU Zygisk Module - 真正的 Root 隐藏实现
# 使用标准 Zygisk API

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := panda_zygisk
LOCAL_SRC_FILES := native.cpp
LOCAL_LDLIBS := -llog -landroid -lstdc++
include $(BUILD_SHARED_LIBRARY)
