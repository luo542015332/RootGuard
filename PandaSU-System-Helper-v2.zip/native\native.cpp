// PandaSU Zygisk Module - Native 实现
// 用于隐藏 Root 痕迹

#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <dlfcn.h>
#include <string.h>
#include <cerrno>
#include <android/log.h>

#define LOG_TAG "PandaSU-Zygisk"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// 隐藏的文件路径
static const char* HIDE_PATHS[] = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/su/bin/su",
    "/data/local/su",
    "/data/adb/su",
    "/data/adb/magisk",
    "/system/xbin/busybox",
    "/system/bin/busybox",
};

// 需要伪装的系统属性
static const char* HIDE_PROPS[] = {
    "ro.debuggable",
    "ro.secure",
    "ro.build.tags",
};

// 属性伪装值
static const char* FAKE_PROP_VALUES[] = {
    "0",    // ro.debuggable = 0 (非调试模式)
    "1",    // ro.secure = 1 (安全模式)
    "release-keys",  // ro.build.tags = release-keys
};

// 检查是否是需要隐藏的应用
static bool should_hide_app(const char* process_name) {
    // 需要隐藏 Root 痕迹的应用列表
    // 这里应该从配置读取，简化处理
    return true;
}

// 挂钩文件访问
static int (*original_open)(const char*, int, ...) = nullptr;
static int (*original_stat)(const char*, struct stat*) = nullptr;
static int (*original_lstat)(const char*, struct stat*) = nullptr;
static int (*original_access)(const char*, int) = nullptr;
static char* (*original_readlink)(const char*, char*, size_t) = nullptr;

// Hook: open
static int hooked_open(const char* path, int flags, ...) {
    mode_t mode = 0;
    va_list args;
    va_start(args, flags);
    if (flags & O_CREAT) {
        mode = va_arg(args, mode_t);
    }
    va_end(args);

    // 检查是否是隐藏路径
    for (size_t i = 0; i < sizeof(HIDE_PATHS) / sizeof(HIDE_PATHS[0]); i++) {
        if (strstr(path, HIDE_PATHS[i]) != nullptr) {
            LOGD("Hooked open for hidden path: %s", path);
            errno = ENOENT;
            return -1;
        }
    }

    return original_open(path, flags, mode);
}

// Hook: stat
static int hooked_stat(const char* path, struct stat* buf) {
    for (size_t i = 0; i < sizeof(HIDE_PATHS) / sizeof(HIDE_PATHS[0]); i++) {
        if (strstr(path, HIDE_PATHS[i]) != nullptr) {
            LOGD("Hooked stat for hidden path: %s", path);
            errno = ENOENT;
            return -1;
        }
    }
    return original_stat(path, buf);
}

// Hook: lstat
static int hooked_lstat(const char* path, struct stat* buf) {
    for (size_t i = 0; i < sizeof(HIDE_PATHS) / sizeof(HIDE_PATHS[0]); i++) {
        if (strstr(path, HIDE_PATHS[i]) != nullptr) {
            LOGD("Hooked lstat for hidden path: %s", path);
            errno = ENOENT;
            return -1;
        }
    }
    return original_lstat(path, buf);
}

// Hook: access
static int hooked_access(const char* path, int mode) {
    for (size_t i = 0; i < sizeof(HIDE_PATHS) / sizeof(HIDE_PATHS[0]); i++) {
        if (strstr(path, HIDE_PATHS[i]) != nullptr) {
            LOGD("Hooked access for hidden path: %s", path);
            return -1;
        }
    }
    return original_access(path, mode);
}

// Hook: readlink
static char* hooked_readlink(const char* path, char* buf, size_t bufsiz) {
    for (size_t i = 0; i < sizeof(HIDE_PATHS) / sizeof(HIDE_PATHS[0]); i++) {
        if (strstr(path, HIDE_PATHS[i]) != nullptr) {
            LOGD("Hooked readlink for hidden path: %s", path);
            errno = ENOENT;
            return nullptr;
        }
    }
    return original_readlink(path, buf, bufsiz);
}

// Zygisk 模块入口
extern "C" {

// 模块加载时调用
__attribute__((constructor))
static void module_load() {
    LOGI("PandaSU Zygisk Module loaded");
}

// 模块卸载时调用
__attribute__((destructor))
static void module_unload() {
    LOGI("PandaSU Zygisk Module unloaded");
}

// JNI 入口
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("PandaSU JNI OnLoad");
    return JNI_VERSION_1_6;
}

} // extern "C"

// 初始化 Hook
static void init_hooks() {
    LOGD("Initializing PandaSU hooks...");

    // 获取原始函数地址
    original_open = (int (*)(const char*, int, ...))dlsym(RTLD_NEXT, "open");
    original_stat = (int (*)(const char*, struct stat*))dlsym(RTLD_NEXT, "stat");
    original_lstat = (int (*)(const char*, struct stat*))dlsym(RTLD_NEXT, "lstat");
    original_access = (int (*)(const char*, int))dlsym(RTLD_NEXT, "access");
    original_readlink = (char* (*)(const char*, char*, size_t))dlsym(RTLD_NEXT, "readlink");

    if (!original_open || !original_stat || !original_lstat ||
        !original_access || !original_readlink) {
        LOGE("Failed to resolve original functions");
        return;
    }

    LOGD("PandaSU hooks initialized successfully");
}

// Zygisk 入口点 - Zygisk模块被加载时调用
void onZygotePostFork() {
    init_hooks();
    LOGI("PandaSU Zygisk initialized");
}
