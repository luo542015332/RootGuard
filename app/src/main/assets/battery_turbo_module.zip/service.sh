#!/system/bin/sh
FAKE=/data/local/tmp/batt_fake_temp
NODE=/sys/class/power_supply/battery/temp
LOG=/data/local/tmp/batt_turbo.log
mkdir -p /data/local/tmp
[ ! -f "$FAKE" ] && touch "$FAKE" && chmod 666 "$FAKE"
mount --bind "$FAKE" "$NODE" 2> "$LOG"
echo "$FAKE" > /data/local/tmp/batt_turbo_config
chmod 666 /data/local/tmp/batt_turbo_config 2>/dev/null
