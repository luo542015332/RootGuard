#!/system/bin/sh
FAKE=/data/local/tmp/batt_fake_temp
NODE=/sys/class/power_supply/battery/temp
if [ -f "$NODE" ]; then
    cat "$NODE" > "$FAKE" 2>/dev/null
fi
chmod 666 "$FAKE" 2>/dev/null
